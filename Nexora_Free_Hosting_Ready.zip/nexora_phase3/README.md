# Nexora Phase 3 — Real Backend Starter

This package upgrades the Nexora demo with a Node.js/Express + SQLite backend starter.

## Run on a computer/server
1. Install Node.js 20+.
2. Open terminal in `server`.
3. Run `npm install`.
4. Set `JWT_SECRET` to a long random secret.
5. Run `npm start`.
6. Open http://localhost:3000

Admin demo: admin@nexora.local / admin123

## API
POST /api/auth/register
POST /api/auth/login
GET /api/listings
POST /api/listings (Bearer token)
POST /api/upload (Bearer token, multipart image)
POST /api/purchases (Bearer token)
GET /api/me (Bearer token)
GET /api/admin/stats (admin Bearer token)

Important: payment, blockchain, production security, email verification, rate limiting, cloud storage and real wallet signing still need to be integrated before launch.
