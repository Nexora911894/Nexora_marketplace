import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import path from 'path';
import {fileURLToPath} from 'url';
import fs from 'fs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_THIS_SECRET_IN_PRODUCTION';
const db=new Database(path.join(__dirname,'nexora.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT DEFAULT 'user',created_at TEXT DEFAULT CURRENT_TIMESTAMP);CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,title TEXT NOT NULL,description TEXT,price REAL NOT NULL,image TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_id INTEGER,listing_id INTEGER,amount REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(buyer_id) REFERENCES users(id),FOREIGN KEY(listing_id) REFERENCES listings(id));`);
const adminEmail='admin@nexora.local';
if(!db.prepare('SELECT id FROM users WHERE email=?').get(adminEmail)) db.prepare('INSERT INTO users(email,password,role) VALUES(?,?,?)').run(adminEmail,bcrypt.hashSync('admin123',10),'admin');
app.use(cors());app.use(express.json({limit:'5mb'}));app.use(express.urlencoded({extended:true}));
const uploadDir=path.join(__dirname,'uploads');fs.mkdirSync(uploadDir,{recursive:true});
const upload=multer({dest:uploadDir,limits:{fileSize:10*1024*1024}});
app.use('/uploads',express.static(uploadDir));app.use(express.static(path.join(__dirname,'../public')));
function auth(req,res,next){try{const token=(req.headers.authorization||'').replace('Bearer ','');req.user=jwt.verify(token,JWT_SECRET);next()}catch{return res.status(401).json({error:'Unauthorized'})}}
function sign(u){return jwt.sign({id:u.id,email:u.email,role:u.role},JWT_SECRET,{expiresIn:'7d'})}
app.post('/api/auth/register',(req,res)=>{const {email,password}=req.body;if(!email||!password||password.length<6)return res.status(400).json({error:'Email and password (6+ chars) required'});try{const info=db.prepare('INSERT INTO users(email,password) VALUES(?,?)').run(email.toLowerCase(),bcrypt.hashSync(password,10));const u=db.prepare('SELECT id,email,role FROM users WHERE id=?').get(info.lastInsertRowid);res.json({user:u,token:sign(u)})}catch{return res.status(409).json({error:'Email already exists'})}});
app.post('/api/auth/login',(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE email=?').get((req.body.email||'').toLowerCase());if(!u||!bcrypt.compareSync(req.body.password||'',u.password))return res.status(401).json({error:'Invalid credentials'});res.json({user:{id:u.id,email:u.email,role:u.role},token:sign(u)})});
app.get('/api/listings',(req,res)=>res.json(db.prepare('SELECT l.*,u.email seller FROM listings l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC').all()));
app.post('/api/listings',auth,(req,res)=>{const {title,description,price,image}=req.body;if(!title||!price)return res.status(400).json({error:'Title and price required'});const r=db.prepare('INSERT INTO listings(user_id,title,description,price,image) VALUES(?,?,?,?,?)').run(req.user.id,title,description||'',Number(price),image||'');res.json(db.prepare('SELECT * FROM listings WHERE id=?').get(r.lastInsertRowid))});
app.post('/api/upload',auth,upload.single('image'),(req,res)=>res.json({url:`/uploads/${req.file.filename}`}));
app.post('/api/purchases',auth,(req,res)=>{const l=db.prepare('SELECT * FROM listings WHERE id=?').get(req.body.listingId);if(!l)return res.status(404).json({error:'Listing not found'});const r=db.prepare('INSERT INTO purchases(buyer_id,listing_id,amount) VALUES(?,?,?)').run(req.user.id,l.id,l.price);res.json({id:r.lastInsertRowid,message:'Purchase recorded',amount:l.price})});
app.get('/api/me',auth,(req,res)=>res.json(db.prepare('SELECT id,email,role,created_at FROM users WHERE id=?').get(req.user.id)));
app.get('/api/admin/stats',auth,(req,res)=>{if(req.user.role!=='admin')return res.status(403).json({error:'Admin only'});res.json({users:db.prepare('SELECT COUNT(*) c FROM users').get().c,listings:db.prepare('SELECT COUNT(*) c FROM listings').get().c,purchases:db.prepare('SELECT COUNT(*) c FROM purchases').get().c,revenue:db.prepare('SELECT COALESCE(SUM(amount),0) s FROM purchases').get().s})});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'../public/index.html')));
app.listen(PORT,()=>console.log(`Nexora running on http://localhost:${PORT}`));
