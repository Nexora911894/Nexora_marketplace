# Nexora — Free Hosting Ready

This package is prepared for a simple **Render Free Web Service** deployment. The frontend and Node/Express API run from the same service, so you do not need separate frontend hosting.

## Included
- Nexora English-only responsive marketplace UI
- User registration/login with hashed passwords
- Admin dashboard and listing moderation
- Create/list/sell flow
- Image upload
- Browser wallet connection
- Stripe Checkout integration (add your own Stripe keys when ready)
- Order records
- API health endpoint
- Render deployment blueprint (`render.yaml`)
- Node 22 configuration
- HTTPS provided by Render

## Important free-tier limitation
The app currently uses SQLite and local uploads. Render's free web service has an **ephemeral filesystem**, so SQLite data and uploaded files can be lost after a service restart/redeploy. This package is therefore best for **testing, demo, and early launch**.

For permanent production data later, migrate the database to PostgreSQL/Supabase and image storage to object storage (or upgrade to a host with persistent storage).

## Easiest deployment
1. Create a free account on Render.
2. Put this project in a GitHub repository.
3. In Render choose **New → Blueprint** and select the repository containing `render.yaml`.
4. Set `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD`.
5. After deployment, set `APP_URL` to the Render HTTPS URL shown for the service.
6. Open the Render URL and test `/api/health`.

Your first public URL will look like:
`https://nexora-marketplace.onrender.com`

You can connect a paid custom domain later without changing the application structure.

## Stripe
Payments remain disabled until you add:
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `APP_URL`

Webhook URL:
`https://YOUR-DOMAIN/api/stripe/webhook`

Subscribe to `checkout.session.completed`.

## Admin
Use the `ADMIN_EMAIL` and `ADMIN_PASSWORD` environment variables on first deployment. Change them to your own values before going live.
