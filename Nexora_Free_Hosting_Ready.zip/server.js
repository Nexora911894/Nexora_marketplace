import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import Stripe from 'stripe';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const PORT=Number(process.env.PORT||3000);
const APP_URL=(process.env.APP_URL||`http://localhost:${PORT}`).replace(/\/$/,'');
const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_THIS_SECRET_IN_PRODUCTION';
const stripe=process.env.STRIPE_SECRET_KEY?new Stripe(process.env.STRIPE_SECRET_KEY):null;
const dataDir=path.join(__dirname,'data');
const uploadsDir=path.join(__dirname,'uploads');
fs.mkdirSync(dataDir,{recursive:true});
fs.mkdirSync(uploadsDir,{recursive:true});
const db=new Database(path.join(dataDir,'nexora.db'));

db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',wallet TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,title TEXT NOT NULL,description TEXT DEFAULT '',price REAL NOT NULL,image TEXT DEFAULT '',category TEXT DEFAULT 'Art',status TEXT NOT NULL DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_id INTEGER NOT NULL,listing_id INTEGER NOT NULL,amount REAL NOT NULL,currency TEXT DEFAULT 'usd',status TEXT NOT NULL DEFAULT 'pending',stripe_session_id TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(buyer_id) REFERENCES users(id),FOREIGN KEY(listing_id) REFERENCES listings(id));
CREATE TABLE IF NOT EXISTS follows(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,creator_id INTEGER NOT NULL,UNIQUE(user_id,creator_id));
`);

const adminEmail=(process.env.ADMIN_EMAIL||'admin@nexora.local').toLowerCase();
const adminPassword=process.env.ADMIN_PASSWORD||'admin123';
if(!db.prepare('SELECT id FROM users WHERE email=?').get(adminEmail)){
  db.prepare('INSERT INTO users(email,password_hash,role) VALUES(?,?,?)').run(adminEmail,bcrypt.hashSync(adminPassword,12),'admin');
}

app.use(helmet({contentSecurityPolicy:false,crossOriginEmbedderPolicy:false}));
app.use(cors());
app.use('/api/stripe/webhook',express.raw({type:'application/json'}));
app.use(express.json({limit:'4mb'}));
app.use(express.urlencoded({extended:true}));
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));

const upload=multer({dest:uploadsDir,limits:{fileSize:10*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype))});
app.use('/uploads',express.static(uploadsDir));
app.use(express.static(path.join(__dirname,'public')));

function tokenFor(u){return jwt.sign({id:u.id,email:u.email,role:u.role},JWT_SECRET,{expiresIn:'7d'});}
function auth(req,res,next){try{const h=req.headers.authorization||'';const t=h.startsWith('Bearer ')?h.slice(7):'';req.user=jwt.verify(t,JWT_SECRET);next();}catch{res.status(401).json({error:'Unauthorized'});}}
function admin(req,res,next){if(req.user?.role!=='admin')return res.status(403).json({error:'Admin only'});next();}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Nexora',time:new Date().toISOString()}));
app.post('/api/auth/register',(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
  if(!/^\S+@\S+\.\S+$/.test(email)||password.length<8)return res.status(400).json({error:'Use a valid email and password of at least 8 characters.'});
  try{const r=db.prepare('INSERT INTO users(email,password_hash) VALUES(?,?)').run(email,bcrypt.hashSync(password,12));const u=db.prepare('SELECT id,email,role,wallet,created_at FROM users WHERE id=?').get(r.lastInsertRowid);res.json({user:u,token:tokenFor(u)});}catch{res.status(409).json({error:'Email already exists'});}
});
app.post('/api/auth/login',(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase();const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);if(!u||!bcrypt.compareSync(String(req.body.password||''),u.password_hash))return res.status(401).json({error:'Invalid credentials'});res.json({user:{id:u.id,email:u.email,role:u.role,wallet:u.wallet},token:tokenFor(u)});});
app.get('/api/me',auth,(req,res)=>res.json(db.prepare('SELECT id,email,role,wallet,created_at FROM users WHERE id=?').get(req.user.id)));
app.post('/api/wallet/connect',auth,(req,res)=>{const wallet=String(req.body.wallet||'').trim();if(!/^0x[a-fA-F0-9]{40}$/.test(wallet))return res.status(400).json({error:'Invalid wallet address'});db.prepare('UPDATE users SET wallet=? WHERE id=?').run(wallet,req.user.id);res.json({wallet});});

app.get('/api/listings',(req,res)=>{
  const rows=db.prepare(`SELECT l.id,l.title,l.description,l.price,l.image,l.category,l.status,l.created_at,u.email seller,u.id seller_id FROM listings l JOIN users u ON u.id=l.user_id WHERE l.status='approved' ORDER BY l.id DESC`).all();res.json(rows);
});
app.get('/api/my/listings',auth,(req,res)=>res.json(db.prepare('SELECT * FROM listings WHERE user_id=? ORDER BY id DESC').all(req.user.id)));
app.post('/api/upload',auth,upload.single('image'),(req,res)=>{if(!req.file)return res.status(400).json({error:'Image required'});res.json({url:`/uploads/${req.file.filename}`});});
app.post('/api/listings',auth,(req,res)=>{const title=String(req.body.title||'').trim(),description=String(req.body.description||''),category=String(req.body.category||'Art'),price=Number(req.body.price),image=String(req.body.image||'').trim();if(!title||!Number.isFinite(price)||price<=0)return res.status(400).json({error:'Title and valid price are required'});const status=req.user.role==='admin'?'approved':'pending';const r=db.prepare('INSERT INTO listings(user_id,title,description,price,image,category,status) VALUES(?,?,?,?,?,?,?)').run(req.user.id,title,description,price,image,category,status);res.json(db.prepare('SELECT * FROM listings WHERE id=?').get(r.lastInsertRowid));});
app.delete('/api/listings/:id',auth,(req,res)=>{const l=db.prepare('SELECT * FROM listings WHERE id=?').get(req.params.id);if(!l)return res.status(404).json({error:'Not found'});if(l.user_id!==req.user.id&&req.user.role!=='admin')return res.status(403).json({error:'Forbidden'});db.prepare('DELETE FROM listings WHERE id=?').run(l.id);res.json({ok:true});});

app.get('/api/admin/stats',auth,admin,(req,res)=>res.json({users:db.prepare('SELECT COUNT(*) c FROM users').get().c,listings:db.prepare('SELECT COUNT(*) c FROM listings').get().c,purchases:db.prepare("SELECT COUNT(*) c FROM orders WHERE status='paid'").get().c,revenue:db.prepare("SELECT COALESCE(SUM(amount),0) s FROM orders WHERE status='paid'").get().s,pending:db.prepare("SELECT COUNT(*) c FROM listings WHERE status='pending'").get().c}));
app.get('/api/admin/listings',auth,admin,(req,res)=>res.json(db.prepare('SELECT l.*,u.email seller FROM listings l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC').all()));
app.patch('/api/admin/listings/:id',auth,admin,(req,res)=>{const status=['approved','pending','rejected'].includes(req.body.status)?req.body.status:null;if(!status)return res.status(400).json({error:'Invalid status'});db.prepare('UPDATE listings SET status=? WHERE id=?').run(status,req.params.id);res.json({ok:true});});
app.delete('/api/admin/users/:id',auth,admin,(req,res)=>{if(Number(req.params.id)===req.user.id)return res.status(400).json({error:'Cannot delete yourself'});db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);res.json({ok:true});});

app.post('/api/checkout/session',auth,async(req,res)=>{
  if(!stripe)return res.status(503).json({error:'Stripe is not configured. Add STRIPE_SECRET_KEY on your hosting environment.'});
  const listing=db.prepare("SELECT * FROM listings WHERE id=? AND status='approved'").get(req.body.listingId);if(!listing)return res.status(404).json({error:'Listing not found'});if(listing.user_id===req.user.id)return res.status(400).json({error:'You cannot buy your own listing'});
  const order=db.prepare('INSERT INTO orders(buyer_id,listing_id,amount,status) VALUES(?,?,?,?)').run(req.user.id,listing.id,listing.price,'pending');
  try{const session=await stripe.checkout.sessions.create({mode:'payment',line_items:[{price_data:{currency:'usd',product_data:{name:listing.title,description:listing.description?.slice(0,500)||'Nexora collectible',images:listing.image&&listing.image.startsWith('http')?[listing.image]:[]},unit_amount:Math.round(listing.price*100)},quantity:1}],metadata:{orderId:String(order.lastInsertRowid),listingId:String(listing.id),buyerId:String(req.user.id)},success_url:`${APP_URL}/?payment=success`,cancel_url:`${APP_URL}/?payment=cancelled`});db.prepare('UPDATE orders SET stripe_session_id=? WHERE id=?').run(session.id,order.lastInsertRowid);res.json({url:session.url});}catch(e){db.prepare('DELETE FROM orders WHERE id=?').run(order.lastInsertRowid);res.status(500).json({error:e.message});}
});
app.post('/api/stripe/webhook',(req,res)=>{
  if(!stripe||!process.env.STRIPE_WEBHOOK_SECRET)return res.status(503).send('Stripe webhook not configured');
  let event;try{event=stripe.webhooks.constructEvent(req.body,req.headers['stripe-signature'],process.env.STRIPE_WEBHOOK_SECRET);}catch(e){return res.status(400).send(`Webhook Error: ${e.message}`);}
  if(event.type==='checkout.session.completed'){const s=event.data.object;const orderId=Number(s.metadata?.orderId);if(orderId)db.prepare("UPDATE orders SET status='paid' WHERE id=?").run(orderId);}
  res.json({received:true});
});
app.get('/api/orders',auth,(req,res)=>res.json(db.prepare(`SELECT o.*,l.title,l.image FROM orders o JOIN listings l ON l.id=o.listing_id WHERE o.buyer_id=? ORDER BY o.id DESC`).all(req.user.id)));

app.get('/*splat',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Nexora running on ${APP_URL}`));
